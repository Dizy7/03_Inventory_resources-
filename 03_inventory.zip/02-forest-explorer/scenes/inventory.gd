extends CanvasLayer

# Перетащи сюда узел GridContainer в Инспекторе
@export var grid: GridContainer
@export var slot_texture: Texture2D       # Сюда перетащи обрезанную обычную рамку
@export var active_slot_texture: Texture2D # Сюда перетащи обрезанную рамку с белой обводкой


func _ready():
	# Подключаемся к сигналу обновления инвентаря
	Global.inventory_updated.connect(refresh_ui)
	refresh_ui()

func refresh_ui():
	# 1. Очищаем старые кнопки-ячейки
	for child in grid.get_children():
		child.queue_free()
	
	# 2. Создаем новые кнопки на основе данных из Global.inventory
		# 2. Создаем новые кнопки на основе данных из Global.inventory
	for i in range(Global.inventory.size()):
		var item = Global.inventory[i]
		
		var slot = Button.new()
		slot.custom_minimum_size = Vector2(24, 24) # Убедись, что этот размер совпадает с размером твоей рамки
		slot.expand_icon = true
		slot.icon = item.icon
		slot.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
		
		# НАСТРОЙКА ОТСТУПОВ: уменьшаем размер иконки внутри кнопки на 4-6 пикселей, чтобы она села ровно в центр рамки
		slot.add_theme_constant_override("icon_max_width", 14) 
		
		# Создаем стиль для отображения рамки ячейки
		var current_style = StyleBoxTexture.new()
		
		# Выбираем нужную рамку (активную или обычную)
		if i == Global.active_slot_index:
			if active_slot_texture:
				current_style.texture = active_slot_texture
		else:
			if slot_texture:
				current_style.texture = slot_texture
				
		# Применяем рамку к кнопке
		slot.add_theme_stylebox_override("normal", current_style)
		slot.add_theme_stylebox_override("hover", current_style)
		slot.add_theme_stylebox_override("pressed", current_style)
		
		# Убираем дефолтное выделение Godot
		var empty_focus = StyleBoxEmpty.new()
		slot.add_theme_stylebox_override("focus", empty_focus)
		
		grid.add_child(slot)
				# Если предметов больше 1 — пишем количество текстом на кнопке
		if item.amount > 1:
			slot.text = str(item.amount)
			slot.alignment = HORIZONTAL_ALIGNMENT_RIGHT # Сдвигаем цифру в правый угол
			# Настройка пиксельного шрифта, чтобы текст был мелким и аккуратным
			slot.add_theme_constant_override("outline_size", 3) # Обводка текста для читаемости
			slot.add_theme_color_override("font_outline_color", Color.BLACK)




# Функция, которая подсвечивает (выбирает) активный слот белой рамкой
func update_selection_visual():
	var slots = grid.get_children()
	for i in range(slots.size()):
		if i == Global.active_slot_index:
			slots[i].grab_focus() # Кнопка получает фокус (стандартная белая рамка Godot)
		else:
			slots[i].release_focus() # Убираем фокус
