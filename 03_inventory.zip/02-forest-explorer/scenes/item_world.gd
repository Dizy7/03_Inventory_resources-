extends Node2D

# Сюда будет передаваться ресурс (axe, mushroom или wood)
@export var item_resources: ItemData

@onready var sprite: Sprite2D = $Sprite2D


func _ready() -> void:
	if item_resources and sprite:
		sprite.texture = item_resources.icon


# Подключаем встроенный сигнал Area2D (body_entered)
func _on_area_2d_body_entered(body: Node2D) -> void:
	if body.name == "Player":
		# Если инвентарь не забит — подбираем и удаляем с земли
		if Global.add_item(item_resources):
			queue_free()
