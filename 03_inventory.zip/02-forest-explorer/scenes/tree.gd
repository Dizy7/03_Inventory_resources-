extends Node2D

# Сюда в инспекторе перетащим wood.tres
@export var item_resources: ItemData

func _on_area_2d_body_entered(body: Node2D) -> void:
	if body.name == "Player":
		if body.equipped_tool and body.equipped_tool.name == "axe":
			# Если инвентарь полон — дерево не рубится
			if Global.add_item(item_resources):
				queue_free()


func spawn_wood():
	if item_resources:
		Global.add_item(item_resources)
