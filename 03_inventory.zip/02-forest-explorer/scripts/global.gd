extends Node

signal inventory_updated

var inventory: Array[ItemData] = []
var active_slot_index: int = 0
var player_name: String = "Игрок"

# PHASE_13: Максимальное количество ЯЧЕЕК в инвентаре
@export var max_inventory_size: int = 6

func add_item(item: ItemData) -> bool:
	# 1. Проверяем, есть ли уже такой предмет в инвентаре (по имени)
	for existing_item in inventory:
		if existing_item.name == item.name:
			# Если нашли — увеличиваем количество и обновляем UI
			existing_item.amount += 1
			inventory_updated.emit()
			return true # Успешно подобрано (стакнулось)
			
	# 2. Если предмета нет, проверяем лимит ячеек инвентаря
	if inventory.size() < max_inventory_size:
		# Перед добавлением новой ячейки убедимся, что количество сброшено в 1
		item.amount = 1 
		inventory.append(item)
		inventory_updated.emit()
		return true # Успешно подобрано в новую ячейку
		
	# 3. Если инвентарь забит и предмет новый — возвращаем false (не подобрано)
	return false
