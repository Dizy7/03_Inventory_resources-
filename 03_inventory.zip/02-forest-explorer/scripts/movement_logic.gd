extends CharacterBody2D

var speed = 40
@export var anim: AnimatedSprite2D
@export var item_world_scene: PackedScene

# --- Новые переменные для инвентаря и рук ---
@export var hand: Sprite2D
@export var default_axe: ItemData
var equipped_tool: ItemData

# Флаг для sit
var is_sitting = false

func _ready() -> void:
	# Выдаем топор на старте игры
	if default_axe:
		Global.add_item(default_axe)
	# Сразу обновляем внешний вид рук
	update_hand_visual()

func _physics_process(_delta):
	var input = Vector2(Input.get_action_strength('ui_right') - Input.get_action_strength('ui_left'), Input.get_action_strength('ui_down') - Input.get_action_strength('ui_up'))
	velocity = input.normalized() * speed
	
	if is_sitting:
		velocity = Vector2.ZERO
		move_and_slide()
		return
		
	# Поворот спрайта в зависимости от направления персонажа
	if input.x > 0:
		anim.flip_h = true
		if hand: hand.position.x = abs(hand.position.x) # Смещаем руку вправо при развороте
	elif input.x < 0:
		anim.flip_h = false
		if hand: hand.position.x = -abs(hand.position.x) # Смещаем руку влево при развороте
		
	# Переключение состояний анимации
	if input != Vector2.ZERO:
		anim.play('walk')
	else:
		anim.play('idle')
	move_and_slide()

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed('interact'):
		if is_sitting:
			is_sitting = false
			anim.play('idle')
		else:
			is_sitting = true
			anim.play('sit')
			
	# --- Логика переключения предметов колесиком мыши ---
	if event.is_action_pressed('next_item'):
		change_selection(1)
	if event.is_action_pressed('prev_item'):
		change_selection(-1)
	if event.is_action_pressed("drop_item"):
		drop_item()
# Функция изменения активного слота
func change_selection(direction: int):
	if Global.inventory.size() == 0: return
	
	# Зацикливаем индекс по кругу в зависимости от размера инвентаря
	Global.active_slot_index = (Global.active_slot_index + direction) % Global.inventory.size()
	if Global.active_slot_index < 0: 
		Global.active_slot_index = Global.inventory.size() - 1
	
	# Обновляем визуальное отображение предмета в руке
	update_hand_visual()
	Global.inventory_updated.emit()


# Функция обновления спрайта в руке игрока
func update_hand_visual():
	if Global.inventory.size() > 0 and Global.active_slot_index < Global.inventory.size():
		var item = Global.inventory[Global.active_slot_index]
		if item:
			hand.texture = item.icon
			# Если предмет является инструментом (топором) — записываем его, иначе сбрасываем
			equipped_tool = item if item.is_tool else null
	else:
		hand.texture = null
		equipped_tool = null
func drop_item():
	if Global.inventory.size() > 0:
		# Получаем предмет из активного слота
		var item_to_drop = Global.inventory[Global.active_slot_index]

		# Удаляем его из массива инвентаря
		Global.inventory.remove_at(Global.active_slot_index)

		# Спавним его на земле (если сцена привязана)
		if item_world_scene:
			spawn_dropped_item(item_to_drop)

		# Корректируем индекс, чтобы он не вышел за границы массива
		Global.active_slot_index = clamp(Global.active_slot_index, 0, Global.inventory.size() - 1)

		# Обновляем инвентарь и руку
		Global.inventory_updated.emit()
		update_hand_visual()

func spawn_dropped_item(item_to_drop: ItemData):
	var new_item = item_world_scene.instantiate()
	new_item.item_resources = item_to_drop

	# Небольшой случайный разброс вокруг игрока, чтобы предметы не ложились в одну точку
	var random_offset = Vector2(randf_range(-15, 15), randf_range(-15, 15))
	new_item.position = self.position + random_offset

	get_tree().current_scene.add_child(new_item)
